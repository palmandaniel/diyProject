# diyProject
Lajtos Dávid, Szalatnyai Balázs, Papp Ádám, Palman Dániel közös projektfeladata
